package com.example.demo.entity;



public class Calculate {

	
	private float a;
	private String operator;
	private float b;
	
	public Calculate() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	public float getA() {
		return a;
	}

	public void setA(float a) {
		this.a = a;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public float getB() {
		return b;
	}

	public void setB(float b) {
		this.b = b;
	}

	public Calculate(float a, String operator, float b) {
		super();
		this.a = a;
		this.operator = operator;
		this.b = b;
	}

	@Override
	public String toString() {
		return "Calculate [a=" + a + ", operator=" + operator + ", b=" + b + "]";
	}
	
	
	
}
