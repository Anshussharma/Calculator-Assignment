package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Calculate;
import com.example.demo.entity.MemoryCalculator;

public interface CalculatorService {

	public float calculateOperation( List<String> equation);
	public void memorySave(List<String> result);
	public float memoryResult();
	public void memoryClear();
}
