package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Calculate;
import com.example.demo.entity.MemoryCalculator;
import com.example.demo.repo.CalculatorRepo;

@Service
public class CalculatorServiceImpl implements CalculatorService{

	@Autowired
	public CalculatorRepo calRepo;
	
	@Override
	public float calculateOperation( List<String> equation) {
		// TODO Auto-generated method stub
		
		//try{
			Calculate cal=new Calculate(Float.valueOf(equation.get(0)),equation.get(1),Float.valueOf(equation.get(2)));
		
		
		float a=cal.getA();
		float b=cal.getB();
		String opt=cal.getOperator();
		float c=0;
		switch(opt) {
		case "+":
			c=a+b;
			break;
		
		case "-":
			c=a-b;
			break;
			
		case "*":
			c=a*b;
			break;
		
		case "/":
			c=a/b;
			break;	
			
		case "^":
			c=b*b;
			break;
			
		case "$":
			c= (float) Math.sqrt(b);
			break;
			
		case "!":
			c=1/b;
		}
		
		return (float)c;
		//}
//		catch(Exception e) {
//			System.out.println("something went wrong");
//			return 0;
//		}
	}

	@Override
	public void memorySave(List<String> result) {
		// TODO Auto-generated method stub
		MemoryCalculator value=new MemoryCalculator(Float.valueOf(result.get(1)+result.get(0)));
		calRepo.save(value);
	}

	@Override
	public float memoryResult() {
		// TODO Auto-generated method stub
		List<Float> list=new ArrayList<>();
		list=calRepo.findAllResult();
		float final_result=0;
		 for(float i:list) {
			 final_result+=i;
		 }
		 return final_result ;
	}

	@Override
	public void memoryClear() {
		// TODO Auto-generated method stub
		calRepo.deleteAll();
	}
	
	

}
