import './App.css';
import Calculator from './Components/calculator';
import Navbar from './Components/navbar';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Calculator />
    </div>
  );
}

export default App;
