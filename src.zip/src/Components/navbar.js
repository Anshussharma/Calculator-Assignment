import React from 'react';

function Navbar() {
    return (
      <div className="navbar-brand">
        <h1>Calculator</h1>
      </div>
    );
  }
  
  export default Navbar;