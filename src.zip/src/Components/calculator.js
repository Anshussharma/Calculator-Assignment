
import axios from "axios";
import React, { useState } from "react";



function Calculator() {
  const [currentView, setCurrentView] = useState("");
  const [equation, setEquation] = useState([]);
  const [count, setCount] = useState(0);
  const [endresult, setEndresult] = useState([]);  

  const handleClick = value => {
    
    const result = equation
    .join("")
    .split(" ")
    .map(value => (value.match(/\d/g) ? parseFloat(value, 0) : value))
    

   // if(result.length===1 && result[2]!=="")
  //  if(count===2){
  //     setCount(0)
  //     axios.post("http://localhost:8080/equals",equation).then(
  //       (res)=>{
         
  //           setEquation(res.data);

          
  //       }
  //     ).catch((error) => console.log(error.res.request._res))
  //     console.log(result);
  //   setCurrentView(result);
  //   setEquation([""]);
  //     setEquation([...equation, value]);  
      
  //     console.log(equation+"******");
      
  //   }  
   // else{
      setCurrentView(result);
      setEndresult(result);
      setEquation([...equation, value]);
   // }
    
    
  
  };
  const handleClear = () =>{

      
      setEquation(equation.pop());
      setEquation([equation.join("")]);
      //setEquation([equation.push("")]);
      console.log(equation);
    
  }
  const handleClick1 = value => {
    setCount(count+1);
    
  
    const result = equation
    .join("")
    .split(" ")
    .map(value => (value.match(/\d/g) ? parseFloat(value, 0) : value))
    
    setEndresult(result);
   // if(result.length===1 && result[2]!=="")
   if(count===1){
      setCount(0)
      axios.post("http://localhost:8080/equals",result).then(
        (res)=>{
         
            setEquation(res.data);

          
        }
      ).catch((error) => console.log(error.res.request._res))
      console.log(result);
    setCurrentView(result);
    setEquation([""]);
      setEquation([...equation, value]);  
      
      console.log(equation+"******");
      
    }  
    else{
      setCurrentView(result);
    
      setEquation([...equation, value]);
    }
    
    
  
  };

  const handleMemory = value => {
    
    
    
    setCount(0);
    if(value==="M+"){ 
      equation.push(" + ")
     // equation.push(" ")
      const result = equation
    .join("")
    .split(" ")
    .map(value => (value.match(/\d/g) ? parseFloat(value, 0) : value))
      console.log(equation+"******");
      console.log(result);
      axios.post("http://localhost:8080/save",result)
    setCurrentView(result);
    setEquation([""]);
      }
      else if(value==="M-"){
        equation.push(" - ")
        const result = equation
    .join("")
    .split(" ")
    .map(value => (value.match(/\d/g) ? parseFloat(value, 0) : value))
        console.log(equation);
        console.log(result);
        axios.post("http://localhost:8080/save",result)
        
      setCurrentView(result);
      setEquation([""]);
        }
       else if(value==="MR"){
          
          axios.get("http://localhost:8080/result").then(
            (res)=>{
             
                setEquation([res.data]);
    
              
            }
          ).catch((error) => console.log(error.res.request._res))
         
        setCurrentView(equation);
        //setEquation([""]);
          }

        else if(value==="MC"){
            
            axios.get("http://localhost:8080/clear")
            setEndresult([0])
          setCurrentView(0);
          setEquation([""]);
            }
  };
  const handleResult = () => {
    setCount(0);
    const result = equation
      .join("")
      .split(" ")
      .map(value => (value.match(/\d/g) ? parseFloat(value, 0) : value))
      
      axios.post("http://localhost:8080/equals",result).then(
        (res)=>{
         
            setEquation([res.data]);

          
        }
      ).catch((error) => console.log(error.res.request._res))
      console.log(result);
    setCurrentView(result);
   // setEquation([""]);
  };


  return (
    <>
    <div className="calc-body">
      <div className="calc-screen">
    <div id="calc-operation">{currentView} </div>
    <div id="calc-typed">{equation}</div>
</div>
      

      <div className="calc-button-row">
      <button className="opt" onClick={() => handleMemory("M+")}>M+</button>
      <button className="opt" onClick={() => handleMemory("M-")}>M-</button>
      <button className="opt" onClick={() => handleMemory("MR")}>MR</button>
      <button className="opt" onClick={() => handleMemory("MC")}>MC</button>
         <button className="opt" onClick={() => handleClick1("0 ^ ")}>x^2</button>
         <button className="opt" onClick={() => handleClick1("0 $ ")}>&#8730;x</button>
         <button className="opt" onClick={() => handleClick1("0 ! ")}>1/x</button>
         <button className="ac" onClick={()=>handleClear()}>C</button>
         <button className="ac" onClick={()=>setEquation([""])}>AC</button>
          <button className="opt">&#43;&#47;&#8722;</button>
          <button className="opt">&#37;</button>
          <button className="opt" onClick={() => handleClick1(" + ")}>+</button>
          
          <button onClick={() => handleClick(7)}>7</button>
          <button onClick={() => handleClick(8)}>8</button>
          <button onClick={() => handleClick(9)}>9</button>
          <button className="opt" onClick={() => handleClick1(" / ")}>÷</button>
          <button onClick={() => handleClick(4)}>4</button>
          <button onClick={() => handleClick(5)}>5</button>
          <button onClick={() => handleClick(6)}>6</button>
          <button className="opt" onClick={() => handleClick1(" * ")}>x</button>
          <button onClick={() => handleClick(1)}>1</button>
          <button onClick={() => handleClick(2)}>2</button>
          <button onClick={() => handleClick(3)}>3</button>
          <button className="opt" onClick={() => handleClick1(" - ")}>-</button>
          <button onClick={() => handleClick(0)}>0</button>
          <button onClick={() => handleClick(".")}>.</button>
          <button className="opt" onClick={() => handleResult()}>=</button>
          <button onClick={()=>handleClear()}>&#9003;</button>
          
        </div>
        </div>
        </>
  );
}

export default Calculator;